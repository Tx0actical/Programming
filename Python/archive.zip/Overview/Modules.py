import math

print("The square root of 16 is", math.sqrt(16))

print("Pi is", math.pi)